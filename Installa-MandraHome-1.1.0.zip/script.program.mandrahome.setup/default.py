import hashlib
import json
import shutil
import time
import zipfile
from pathlib import Path, PurePosixPath

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

TITLE='Mandra Home - Configurazione'
IDS=['plugin.video.mandrakodi','skin.estuary.skyhome','service.mandra.autostart']

def rpc(method,params):
    response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
    if 'error' in response: raise RuntimeError(response['error'].get('message','Errore Kodi'))
    return response['result']

def main():
    if int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])!=21:
        xbmcgui.Dialog().ok(TITLE,'Questo pacchetto e previsto per Kodi 21.x. Nessuna modifica applicata.')
        return
    source=Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')))/'resources'
    root=Path(xbmcvfs.translatePath('special://home/'))
    backup=root/'mandra-home-backups'/time.strftime('%Y%m%d-%H%M%S')
    backups=[]; applied=[]; settings_changed=False
    previous_skin=rpc('Settings.GetSettingValue',{'setting':'lookandfeel.skin'})['value']
    stage=Path(xbmcvfs.translatePath('special://temp/'))/('mandra-home-'+time.strftime('%Y%m%d-%H%M%S'))
    progress=xbmcgui.DialogProgress(); progress.create(TITLE,'Controllo dei file...')
    try:
        expected=json.loads((source/'manifest.json').read_text(encoding='utf-8'))
        with zipfile.ZipFile(source/'payload.zip') as z:
            actual=set()
            for info in z.infolist():
                parts=PurePosixPath(info.filename).parts
                if not parts or parts[0] not in IDS or '..' in parts or '\\' in info.filename or info.filename.startswith('/'):
                    raise RuntimeError('Percorso non valido nel pacchetto')
                if info.is_dir(): continue
                if info.filename not in expected: raise RuntimeError('File inatteso nel pacchetto')
                raw=z.read(info)
                if hashlib.sha256(raw).hexdigest()!=expected[info.filename]: raise RuntimeError('Verifica integrita fallita')
                actual.add(info.filename)
            if actual!=set(expected): raise RuntimeError('Pacchetto incompleto')
            z.extractall(stage)
        for index,addon_id in enumerate(IDS):
            progress.update(20+index*20,'Installazione '+addon_id)
            dest=root/'addons'/addon_id
            if dest.is_symlink(): raise RuntimeError('Cartella collegata non supportata: '+addon_id)
            if dest.exists():
                backup.mkdir(parents=True,exist_ok=True)
                shutil.copytree(dest,backup/addon_id)
                backups.append(addon_id)
            applied.append(addon_id)
            shutil.copytree(stage/addon_id,dest,dirs_exist_ok=True)
        xbmc.executebuiltin('UpdateLocalAddons',True)
        monitor=xbmc.Monitor()
        for addon_id in IDS:
            for attempt in range(30):
                try:
                    rpc('Addons.GetAddonDetails',{'addonid':addon_id,'properties':['enabled']})
                    rpc('Addons.SetAddonEnabled',{'addonid':addon_id,'enabled':True})
                    break
                except RuntimeError:
                    if attempt==29: raise
                    if monitor.waitForAbort(0.5): raise RuntimeError('Kodi in chiusura')
        progress.update(90,'Configurazione della schermata principale...')
        progress.close()
        xbmcgui.Dialog().ok(TITLE,'Configurazione installata. Alla richiesta di mantenere la nuova skin scegli SI. Poi riavvia Kodi. Troverai TV SKY, Live TV, Sport, On Demand e Radio nella Home.')
        rpc('Settings.SetSettingValue',{'setting':'lookandfeel.skin','value':'skin.estuary.skyhome'})
        settings_changed=True
    except Exception as exc:
        progress.close()
        if settings_changed:
            try: rpc('Settings.SetSettingValue',{'setting':'lookandfeel.skin','value':previous_skin})
            except Exception: pass
        for addon_id in reversed(applied):
            dest=root/'addons'/addon_id
            if addon_id in backups:
                shutil.copytree(backup/addon_id,dest,dirs_exist_ok=True)
        xbmc.log('MANDRA-HOME-SETUP: '+str(exc),xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE,'Installazione non completata: '+str(exc)+'\nEventuali copie precedenti conservate in '+str(backup)+'. Riavvia Kodi prima di riprovare.')
    finally:
        progress.close()

main()
